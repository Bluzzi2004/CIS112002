import { Link } from "react-router-dom";

export default function Header() {
  return (
    <nav>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/about/drink">About</Link>
        </li>
        <li>
          <Link to="/purchase/product">Purchase</Link>
        </li>
        <li>
          <Link to="/racing/team">Racing</Link>
          </li>
          <li>
            <Link to="/our/beverages">Beverages</Link>
            </li>
      </ul>
    </nav>
  );
}
