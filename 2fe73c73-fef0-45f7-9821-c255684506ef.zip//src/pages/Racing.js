import { Link } from "react-router-dom"
import { racing } from "../assets/racing.jpg"

export default function Racing() {
 return(
    <>
<h1>Our Offical Racing Team!</h1>
<p>
    <img src={racing} alt="Dino Luzzi Race Car"/>
</p>
<h2>Take to the track with the Italian Energy Drink!</h2>
<p>
    Get ready to witness our professional race team rev up their engines as they go for the gold! With the energy provided by <em>Dino Luzzi Energy Drink</em>, nothing can stop them!
</p>
<h3>Meet Our Drivers!</h3>
<ul>
    <li>Micheal D'Orlando</li>
    <li>Nicholas D'Orlando</li>
    <li>Alan Cohen</li>
    <li>Jenn Krpata</li>
    </ul>
<p>
    <Link to="/">Return to Main Page</Link>
</p>
<h3>Wanna seem them in action? Check our offical YouTube page!</h3>
<p>Ready, Set, <a href="https://www.youtube.com/channel/UCneNhW3ZiMGMMlHhPWf17-Q">Start your engines!</a></p>
</>
 );   
}