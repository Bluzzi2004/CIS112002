import { Link } from "react-router-dom";
import poster from "../assets/poster.jpg";

export default function About() {
  return (
    <>
      <h1>What is the Italian Energy Drink?</h1>
      <p>
        The Italian Energy Drink was first launched in the year 2020. It is made
        in Italy and is marketed under the name{" "}
        <em>"Dino Luzzi Energy Drink"</em> under the company IFBC or Italian
        Food and Beverage Corp with the help of Can International S.R.L. through
        partnership. Our sparkling and refreshing drink is designed to give you
        the energy you need through out your day!
      </p>
      <Link to="/">Return to Main Page</Link>
      <h2>Here are the Health Facts about the Italian Energy Drink!</h2>
      <ul id="facts">
        <li>
          Contains Vitamins B2, B3, B5, B6 and B12
          <li>Made with zero fat and cholesterol</li>
          <li>
            Low calorie count <b>(115)</b>
          </li>
          <li>
            Made with ingredients that improve focus & provides a strong energy
            boost that lasts the whole day
          </li>
        </li>
      </ul>
      <p>
        <img src={poster} width="650" height="auto" alt="Energy Drink Poster" />
      </p>
    </>
  );
}
