import { Link } from "react-router-dom";
import glass from "../assets/glass.jpg";

export default function Main() {
  return (
    <>
      <h1>The Italian Energy Drink!</h1>
      <p>
        Welcome to the website of the Italian Energy Drink also known as{" "}
        <em>Dino Luzzi Energy Drink</em>, below there are some links regarding
        the product! You can also use the navigation bar on the top of your screen for an easier search. Enjoy your surfing and we hope you will consider purchasing
        our product!
      </p>
      <p>
        The Italian Energy Drink <em>(Dino Luzzi Energy Drink)</em> is known as
        a sparkling drink with a refreshing flavor and without the metallic
        after taste that many other energy drinks are known to have. Our goal
        with our drink is that we want to be recongized for putting quality
        first so that you can get the energy you need and a refreshing drink
        that will rehydrate you as well! <strong>FIND YOUR POWER!</strong>
      </p>
      <h2>More about us!</h2>
      <p>
        The Italian Energy Drink has been making it's mark across Long Island and is continuing to expand it's reach. We have also been taking our part in the racing world with our offical <Link to="/racing/team">racing team!</Link> 
        </p>
      <p>
        Not to mention, we are also creating new <Link to="/our/beverages">Italian Energy Drink beverages</Link> to help spice up your night! Why not check out how you can make your own!
        </p>
      <h2>Check out more about our product!</h2>
      <p>
        Want to learn more? Check out our page <Link to="/about/drink">About Italian Energy Drink</Link>
      </p>
      Interested in purchasing? Click here to <Link to="/purchase/product">Buy Our Product</Link>
      <p>
        <img
          src={glass}
          width="350"
          height="auto"
          alt="Energy Drink and Glass"
        />
      </p>
    </>
  );
}
