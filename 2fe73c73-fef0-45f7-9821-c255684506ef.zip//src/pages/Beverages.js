import { Link } from "react-router-dom"

export default function Beverages() {
   return (
<>
<h1>Check our unique beverages!</h1>
<p id="nice">"Nothing better then a nice drink in the moonlight!"</p>
<h2>Bet your thristy, Have a drink!</h2>
<h3>Dolce Dino</h3>
<ul class="ingredients">
    <li>1 Cup Ice</li>
    <li>1 Oz Watermelon Schnapps</li>
    <li>1 1/2 Oz Tito's Vodka</li>
    <li>4 Oz <em>Dino Luzzi Energy Drink</em></li>
</ul>
<h3>Kick in the Arse</h3>
<ul class="ingredients">
<li>1 Cup Ice</li>
<li>1 1/2 Oz Jagermeister</li>
<li>6 Oz <em>Dino Luzzi Energy Drink</em></li>
    </ul>
<h3>Dino-Rita</h3>
<ul class="ingredients">
<li>1 Cup Ice</li>
<li>1 Oz Margarita Mix</li>
<li>1 1/2 Oz Tequila</li>
<li>4 Oz Dino Luzzi Energy Drink</li>
    </ul>
<p>
    <Link to="/">Return to Main Page</Link>
</p>
</>
    );
}